require 'spec_helper'

describe 'ansible::hosts' do
    let(:title) { 'webservers' }
end